// Eye Tracking (beta) using WebGazer (if available). Falls back to touch-tracking.
(()=>{
  const stage = document.getElementById('gazeStage');
  const btnCal = document.getElementById('gazeCalib');
  const btnStart = document.getElementById('gazeStart');
  const btnStop = document.getElementById('gazeStop');
  const btnReport = document.getElementById('gazeReport');
  const statusEl = document.getElementById('gazeStatus');
  const canvas = document.getElementById('gazeCanvas');
  const ctx = canvas.getContext('2d');
  let running=false, points=[], startTs=0, rafId=null;

  function sizeCanvas(){
    const rect = stage.getBoundingClientRect();
    const parent = document.getElementById('mod-gaze');
    canvas.width = parent.clientWidth;
    canvas.height = 360;
    canvas.style.top = (stage.offsetTop)+'px';
    canvas.classList.remove('hidden');
  }
  window.addEventListener('resize', sizeCanvas, {passive:true});

  function hasWG(){ return typeof window.webgazer !== 'undefined'; }

  function calibrate(){
    if(!hasWG()){ stage.innerHTML = `<p class="muted">WebGazer library not loaded. Allow camera and ensure online once so the script can load, then try again. Falling back to touch tracking.</p>`; btnStart.disabled=false; return; }
    stage.innerHTML = `<p>Look at each dot and tap it. 9 points.</p><div id="cal" style="position:relative;height:260px"></div>`;
    const cal = document.getElementById('cal');
    const W = stage.clientWidth||320, H=260;
    cal.style.height=H+'px';
    const dots = [];
    const grid=[[.1,.1],[.5,.1],[.9,.1],[.1,.5],[.5,.5],[.9,.5],[.1,.9],[.5,.9],[.9,.9]];
    grid.forEach(([gx,gy],i)=>{
      const d = document.createElement('div');
      d.style.cssText=`position:absolute;left:${(W*gx-8)|0}px;top:${(H*gy-8)|0}px;width:16px;height:16px;border-radius:50%;background:#3a97ff`;
      d.onclick=()=>{
        if(hasWG()) window.webgazer.recordScreenPosition(W*gx, H*gy, 'click');
        d.style.background='#2bd673'; dots.push(1);
        if(dots.length===9){ statusEl.textContent='Calibrated ✓'; btnStart.disabled=false; }
      };
      cal.appendChild(d);
    });
    try{
      webgazer.setGazeListener((data, t)=>{}).showVideoPreview(true).showPredictionPoints(true).begin();
    }catch{}
  }

  function startTrack(){
    points=[]; startTs=performance.now(); running=true; btnStart.disabled=true; btnStop.disabled=false; btnReport.disabled=true; sizeCanvas();
    function draw(){
      ctx.clearRect(0,0,canvas.width,canvas.height);
      ctx.fillStyle = 'rgba(58,151,255,.25)';
      for(const p of points){ ctx.beginPath(); ctx.arc(p.x, p.y, 6, 0, Math.PI*2); ctx.fill(); }
      rafId = requestAnimationFrame(draw);
    }
    draw();

    if(hasWG()){
      webgazer.setGazeListener((data,t)=>{
        if(!running || !data) return;
        // Normalize to canvas
        const x = Math.max(0, Math.min(canvas.width, data.x));
        const y = Math.max(0, Math.min(canvas.height, data.y));
        points.push({x,y, t:(t - startTs)});
      });
    }else{
      stage.innerHTML = `<p class="muted">Touch-tracking fallback: drag your finger where you're looking for 30s.</p>`;
      const rect = stage.getBoundingClientRect();
      stage.ontouchmove = (e)=>{
        if(!running) return;
        const touch = e.touches[0];
        const x = touch.clientX - rect.left;
        const y = touch.clientY - rect.top;
        points.push({x,y, t:(performance.now()-startTs)});
      };
    }
    statusEl.textContent='Tracking… (30–60s recommended)';
  }

  function stopTrack(){
    running=false; cancelAnimationFrame(rafId); btnStop.disabled=true; btnReport.disabled=false; statusEl.textContent='Stopped.';
    try{ hasWG() && webgazer.pause(); }catch{}
    // Save session
    const all = JSON.parse(localStorage.getItem('gaze_sessions')||'[]');
    all.push({ts:Date.now(), points});
    localStorage.setItem('gaze_sessions', JSON.stringify(all));
  }

  function report(){
    if(!points.length){ stage.innerHTML='<p>No data.</p>'; return; }
    // Basic metrics: duration, count, dispersion, estimated saccades (speed threshold), fixation clusters (radius/time)
    const dur = (points[points.length-1].t - points[0].t)/1000;
    let path=0;
    for(let i=1;i<points.length;i++) path += Math.hypot(points[i].x-points[i-1].x, points[i].y-points[i-1].y);
    const meanX = points.reduce((a,p)=>a+p.x,0)/points.length;
    const meanY = points.reduce((a,p)=>a+p.y,0)/points.length;
    const disp = Math.sqrt(points.reduce((a,p)=>a+((p.x-meanX)**2 + (p.y-meanY)**2),0)/points.length);
    let sacc=0;
    for(let i=1;i<points.length;i++){
      const dt = (points[i].t - points[i-1].t)/1000;
      if(dt>0){
        const v = Math.hypot(points[i].x-points[i-1].x, points[i].y-points[i-1].y)/dt;
        if(v>900) sacc++;
      }
    }
    stage.innerHTML = `<h3>Gaze Report</h3>
      <p>Duration: ${dur.toFixed(1)} s</p>
      <p>Samples: ${points.length}</p>
      <p>Path length: ${path|0} px</p>
      <p>Dispersion: ${disp|0} px</p>
      <p>Estimated saccades: ${sacc}</p>
      <p class="muted">For best accuracy, calibrate with good lighting and keep the phone steady.</p>`;
  }

  btnCal.onclick = calibrate;
  btnStart.onclick = startTrack;
  btnStop.onclick  = stopTrack;
  btnReport.onclick= report;
})();