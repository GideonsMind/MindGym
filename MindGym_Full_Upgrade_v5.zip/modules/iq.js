// Full IQ (beta) module
(()=>{
  const stage = document.getElementById('iqStage');
  const btnStart = document.getElementById('iqStart');
  const btnNext  = document.getElementById('iqNext');
  const statusEl = document.getElementById('iqStatus');

  const RNG = seed => { let s = seed||Date.now()%2147483647; return ()=> (s = s*48271%2147483647)/2147483647; };
  const shuffle = (arr,rand=Math.random)=>arr.map(v=>[rand(),v]).sort((a,b)=>a[0]-b[0]).map(v=>v[1]);

  const SUBTESTS = [
    { id:"series", name:"Number Series", items:8, weight:.22 },
    { id:"verbal", name:"Verbal Analogies", items:8, weight:.22 },
    { id:"spans",  name:"Spatial Span",    items:5, weight:.20 },
    { id:"nback",  name:"1-Back",          items:20, weight:.18 },
    { id:"symbol", name:"Symbol Search",   items:18, weight:.18 }
  ];
  const NORMS = {
    series:{mu:5.0, sd:2.0},
    verbal:{mu:5.5, sd:1.9},
    spans :{mu:3.4, sd:1.2},
    nback :{mu:0.65,sd:0.15},
    symbol:{mu:12.0,sd:3.0}
  };

  let state=null;
  function resetState(){
    state = JSON.parse(localStorage.getItem('iq_checkpoint')||'null');
    if(state){ return; }
    state = {
      seed: Date.now(),
      stIndex:0,
      results:{
        series:{correct:0,total:0},
        verbal:{correct:0,total:0},
        spans:{correct:0,total:0,maxSpan:0},
        nback:{hits:0,false:0,totalTargets:0,pressed:0,acc:0},
        symbol:{score:0,correct:0,false:0}
      }
    };
  }
  function checkpoint(){ localStorage.setItem('iq_checkpoint', JSON.stringify(state)); }
  function clearCheckpoint(){ localStorage.removeItem('iq_checkpoint'); }

  function message(html){ stage.innerHTML = html; }
  function choices(question, options, onPick){
    const wrap = document.createElement('div');
    const p = document.createElement('p'); p.textContent = question; wrap.appendChild(p);
    options.forEach(opt=>{
      const btn=document.createElement('button'); btn.className='choice'; btn.textContent=opt;
      btn.onclick=()=>onPick(opt,btn);
      wrap.appendChild(btn);
    });
    stage.innerHTML=''; stage.appendChild(wrap);
  }
  function timer(seconds,onTick,onDone){
    let t=seconds; onTick?.(t);
    const id=setInterval(()=>{ t--; onTick?.(t); if(t<=0){clearInterval(id); onDone?.();}},1000);
    return ()=>clearInterval(id);
  }

  function genNumberSeries(rand){
    const bank=[];
    for(let i=0;i<16;i++){
      const t = Math.floor(rand()*5);
      let seq=[],ans,opts=[];
      if(t===0){
        const start = 3+Math.floor(rand()*7);
        const k = 2+Math.floor(rand()*7);
        for(let j=0;j<4;j++) seq.push(start+j*k);
        ans = start+4*k;
      }else if(t===1){
        const start = 2+Math.floor(rand()*4);
        const k = 2+Math.floor(rand()*4);
        seq=[start,start*k,start*k*k,start*k*k*k]; ans=start*k*k*k*k;
      }else if(t===2){
        const a=2+Math.floor(rand()*5), b=3+Math.floor(rand()*7), start=5+Math.floor(rand()*6);
        seq=[start,start+a,start+a+b,start+a+b+a]; ans=start+a+b+a+b;
      }else if(t===3){
        const start=3+Math.floor(rand()*7), k=2+Math.floor(rand()*4), m=2+Math.floor(rand()*3);
        seq=[start,start+k,(start+k)*m,((start+k)*m)+k]; ans=((((start+k)*m)+k)*m);
      }else{
        const start=2+Math.floor(rand()*6), d0=1+Math.floor(rand()*4);
        let diff=d0; seq=[start];
        for(let j=0;j<3;j++){ seq.push(seq[seq.length-1]+diff); diff+=d0; }
        ans=seq[seq.length-1]+diff;
      }
      const wrongs=new Set();
      while(wrongs.size<4){
        let w = ans + Math.floor(rand()*15)-7;
        if(w!==ans && w>0) wrongs.add(w);
      }
      opts=shuffle([ans,...wrongs],rand);
      bank.push({prompt:`What comes next?\n${seq.join(', ')} , ?`, opts, ans});
    }
    return bank;
  }
  const VERBAL_BANK = [
    ["Bird is to fly as fish is to __","swim","scale","blue","small","fin"],
    ["Pencil is to write as brush is to __","paint","clean","draw","wood","ink"],
    ["Hot is to cold as high is to __","low","tall","slow","deep","thin"],
    ["Puppy is to dog as kitten is to __","cat","lion","mouse","pet","fur"],
    ["Ear is to hear as eye is to __","see","look","blink","watch","sleep"],
    ["Knife is to cut as needle is to __","sew","poke","sharp","thread","pin"],
    ["Rain is to wet as sun is to __","bright","hot","sky","yellow","day"],
    ["Teacher is to school as doctor is to __","hospital","medicine","nurse","clinic","office"],
    ["Part is to whole as page is to __","book","word","chapter","cover","letter"],
    ["Circle is to round as square is to __","cornered","flat","cube","angle","equal"]
  ].map(([q,a,b,c,d,e])=>({prompt:q,opts:[a,b,c,d,e].sort(()=>Math.random()-.5),ans:a}));

  function runSeries(){
    statusEl.textContent="Number Series";
    const bank = genNumberSeries(()=>Math.random()).slice(0,8);
    let i=0, correct=0;
    const ask=()=>{
      const q=bank[i]; state.results.series.total++;
      choices(q.prompt,q.opts,(pick,btn)=>{
        [...stage.querySelectorAll('.choice')].forEach(b=>b.disabled=true);
        if(pick===q.ans){ correct++; btn.classList.add('correct'); } else { btn.classList.add('wrong'); }
        setTimeout(()=>{ if(++i<8){ checkpoint(); ask(); } else { state.results.series.correct=correct; checkpoint(); nextSubtest(); }},500);
      });
    };
    ask();
  }
  function runVerbal(){
    statusEl.textContent="Verbal Analogies";
    const bank = VERBAL_BANK.slice(0,8);
    let i=0, correct=0;
    const ask=()=>{
      const q=bank[i]; state.results.verbal.total++;
      choices(q.prompt,q.opts,(pick,btn)=>{
        [...stage.querySelectorAll('.choice')].forEach(b=>b.disabled=true);
        if(pick===q.ans){ correct++; btn.classList.add('correct'); } else { btn.classList.add('wrong'); }
        setTimeout(()=>{ if(++i<8){ checkpoint(); ask(); } else { state.results.verbal.correct=correct; checkpoint(); nextSubtest(); }},500);
      });
    };
    ask();
  }
  function runSpans(){
    statusEl.textContent="Spatial Span";
    const cols=4, total=16;
    let trials=0, correct=0, maxSpan=0;
    const playOne=()=>{
      if(trials>=5){ state.results.spans={correct,total:5,maxSpan}; checkpoint(); nextSubtest(); return; }
      const seq=[]; const rand=()=>Math.random();
      const len=3+((Math.random()*5)|0);
      while(seq.length<len){ const v=(Math.random()*total)|0; if(!seq.includes(v)) seq.push(v); }
      maxSpan=Math.max(maxSpan,len);
      stage.innerHTML=`<div class="grid" id="g" style="display:grid;grid-template-columns:repeat(${cols},56px);gap:10px;justify-content:flex-start"></div><div class="muted">Memorize the flashing sequence, then repeat.</div>`;
      const g=document.getElementById('g');
      for(let i=0;i<total;i++){ const b=document.createElement('div'); b.className='box'; b.style.cssText='width:56px;height:56px;border-radius:10px;background:#2a3340'; b.dataset.idx=i; g.appendChild(b); }
      let k=0; const id=setInterval(()=>{
        if(k>0) g.children[seq[k-1]].style.background="#2a3340";
        if(k<len){ g.children[seq[k]].style.background="#3a97ff"; k++; }
        else { clearInterval(id); collect(); }
      },600);
      function collect(){
        let pos=0;
        [...g.children].forEach(b=>b.onclick=()=>{
          if(+b.dataset.idx===seq[pos]){ b.style.background="#2bd673"; pos++; if(pos===seq.length){ correct++; lock(); } }
          else{ b.style.background="#ff5a5a"; lock(); }
        });
        function lock(){ [...g.children].forEach(b=>b.onclick=null); setTimeout(()=>{ trials++; playOne(); },400); }
      }
    };
    playOne();
  }
  function runNBack(){
    statusEl.textContent="1-Back";
    stage.innerHTML=`<div style="font-size:42px;margin:10px 0" id="bigL">+</div><div class="row"><button class="btn primary" id="hit">Hit</button><button class="btn" id="miss">No</button></div>`;
    const letters="ABCDEFGHJKLMNPQRSTUVWXYZ".split('');
    let prev=null, idx=0, hits=0, falses=0, totalTargets=0;
    const seq=[];
    for(let i=0;i<20;i++){ const makeMatch=Math.random()<0.25 && prev!==null; const ch=makeMatch?prev:letters[(Math.random()*letters.length)|0]; seq.push(ch); prev=ch; }
    for(let i=1;i<seq.length;i++) if(seq[i]===seq[i-1]) totalTargets++;
    const big=document.getElementById('bigL'), hit=document.getElementById('hit'), miss=document.getElementById('miss'); let allow=false;
    hit.onclick=()=>{ if(!allow) return; const t=idx>0 && seq[idx]===seq[idx-1]; if(t) hits++; else falses++; allow=false; };
    miss.onclick=()=>{ if(!allow) return; const t=idx>0 && seq[idx]===seq[idx-1]; if(t) falses++; allow=false; };
    function step(){ if(idx>=seq.length){ finish(); return; } big.textContent=seq[idx]; allow=true; idx++; setTimeout(step,1800); }
    function finish(){ const acc= totalTargets? hits/totalTargets:0; state.results.nback={hits,hitsTotal:totalTargets,false:falses,acc}; checkpoint(); nextSubtest(); }
    setTimeout(step,800);
  }
  function runSymbol(){
    statusEl.textContent="Symbol Search";
    const SYMSET = ["◇","◆","○","●","□","■","△","▲","☆","★","☼","♢","♣","♠","♧","♤"];
    let trials=0, score=0, correct=0, falseAlm=0;
    function one(){
      if(trials>=18){ state.results.symbol={score,correct,false:falseAlm}; checkpoint(); nextSubtest(); return; }
      trials++;
      const target = SYMSET[(Math.random()*SYMSET.length)|0];
      const present = Math.random()<0.66;
      const row = []; while(row.length<6){ const s = SYMSET[(Math.random()*SYMSET.length)|0]; row.push(s); }
      if(present){ row[(Math.random()*row.length)|0] = target; }
      stage.innerHTML=`<div class="row" style="align-items:center;gap:16px">
        <div class="box" style="font-size:22px;width:56px;height:56px">${target}</div>
        <div class="row">${row.map(s=>`<div class="box">${s}</div>`).join('')}</div>
      </div>
      <div class="row"><button class="btn primary" id="yes">Yes</button><button class="btn" id="no">No</button></div>`;
      function choose(v){
        const hit = (v===true && present);
        const miss= (v===false && !present);
        if(hit||miss){ correct++; score++; } else if(v!==null){ falseAlm++; score=Math.max(0,score-1); }
        setTimeout(one,200);
      }
      document.getElementById('yes').onclick=()=>choose(true);
      document.getElementById('no').onclick=()=>choose(false);
    }
    one();
  }

  function startRun(){
    resetState();
    runCurrent();
  }
  function runCurrent(){
    const st = SUBTESTS[state.stIndex];
    if(!st){ finishRun(); return; }
    stage.innerHTML = `<p><b>${st.name}</b> will start when you press <em>Next</em>.</p>`;
    btnNext.disabled=false;
    btnNext.onclick=()=>{
      btnNext.disabled=true;
      if(st.id==="series") runSeries();
      else if(st.id==="verbal") runVerbal();
      else if(st.id==="spans") runSpans();
      else if(st.id==="nback") runNBack();
      else if(st.id==="symbol") runSymbol();
    };
  }
  function nextSubtest(){ state.stIndex++; checkpoint(); if(state.stIndex < 5) runCurrent(); else finishRun(); }

  function finishRun(){
    const r=state.results;
    const z = {
      series:(r.series.correct-5.0)/2.0,
      verbal:(r.verbal.correct-5.5)/1.9,
      spans :(r.spans.correct-3.4)/1.2,
      nback :((r.nback.acc||0)-0.65)/0.15,
      symbol:((r.symbol.score||0)-12.0)/3.0
    };
    const w = {series:.22, verbal:.22, spans:.20, nback:.18, symbol:.18};
    const g = z.series*w.series + z.verbal*w.verbal + z.spans*w.spans + z.nback*w.nback + z.symbol*w.symbol;
    const iq = Math.round(100 + 15*g);
    const se = 4.5, ci=[Math.round(iq-1.96*se), Math.round(iq+1.96*se)];
    const payload = {ts:Date.now(), iq, ci, z, r};
    const key='iq_full_runs'; const all=JSON.parse(localStorage.getItem(key)||'[]'); all.push(payload); localStorage.setItem(key, JSON.stringify(all));
    localStorage.removeItem('iq_checkpoint');
    stage.innerHTML = `<h3>Estimated IQ: ${iq}</h3><p class="muted">95%: ${ci[0]}–${ci[1]}</p>
      <ul class="muted">
        <li>Number Series: ${r.series.correct}/8</li>
        <li>Verbal Analogies: ${r.verbal.correct}/8</li>
        <li>Spatial Span: ${r.spans.correct}/5</li>
        <li>1-Back: ${(r.nback.acc*100|0)}% acc</li>
        <li>Symbol Search: ${r.symbol.score} score</li>
      </ul>
      <button class="btn" id="again">Retake</button> <button class="btn" id="hist">History</button>`;
    document.getElementById('again').onclick=()=>{ btnNext.disabled=true; };
    document.getElementById('hist').onclick=showHist;
  }
  function showHist(){
    const all = JSON.parse(localStorage.getItem('iq_full_runs')||'[]').slice(-10).reverse();
    if(!all.length){ stage.innerHTML='<p>No runs yet.</p>'; return; }
    stage.innerHTML = '<h3>Last runs</h3>' + all.map(r=>`<div class="panel" style="margin:8px 0"><b>${new Date(r.ts).toLocaleString()}</b> — IQ ${r.iq} (${r.ci[0]}–${r.ci[1]})</div>`).join('');
  }

  btnStart?.addEventListener('click', ()=>{ btnStart.disabled=true; startRun(); });
})();