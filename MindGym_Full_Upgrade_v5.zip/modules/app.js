// Core app routing, settings, storage, small games (focus/circle/visual/nback/matrix/noticing/journal)
(()=>{
  const $ = sel => document.querySelector(sel);
  const $$ = sel => document.querySelectorAll(sel);
  const showToast = (msg)=>{
    const t = $('#toast'); t.textContent = msg; t.classList.add('show');
    setTimeout(()=>t.classList.remove('show'), 1500);
  };

  // Theme
  const themeSel = $('#themeSel');
  function applyTheme(v){ document.documentElement.setAttribute('data-theme', v==='dark'?'':v); localStorage.setItem('theme', v); }
  themeSel.value = localStorage.getItem('theme') || 'dark'; applyTheme(themeSel.value);
  themeSel.onchange = e=>applyTheme(e.target.value);

  // Routing
  const home = $('#home');
  const modules = {
    focus: $('#mod-focus'), circle: $('#mod-circle'), visual: $('#mod-visual'), nback: $('#mod-nback'),
    matrix: $('#mod-matrix'), noticing: $('#mod-noticing'), journal: $('#mod-journal'),
    iqfull: $('#mod-iqfull'), gaze: $('#mod-gaze'), stats: $('#mod-stats'), settings: $('#mod-settings')
  };
  $$('#home .card').forEach(c => c.addEventListener('click', ()=>openMod(c.getAttribute('data-open'))));
  $('#btnSettings').onclick = ()=>openMod('settings');
  $$('.module [data-close]').forEach(b=> b.addEventListener('click', closeAll));
  function closeAll(){ Object.values(modules).forEach(m=>m.classList.add('hidden')); home.classList.remove('hidden'); }
  function openMod(name){ home.classList.add('hidden'); closeAll(); modules[name].classList.remove('hidden'); }

  // Settings
  const optSound = $('#optSound'), optHaptics = $('#optHaptics'), optFps = $('#optFps');
  const settings = JSON.parse(localStorage.getItem('settings')||'{}');
  optSound.checked = !!settings.sound; optHaptics.checked = !!settings.haptics; optFps.value = settings.fps||60;
  $('#saveSettings').onclick = ()=>{
    localStorage.setItem('settings', JSON.stringify({sound:optSound.checked, haptics:optHaptics.checked, fps:+optFps.value||60}));
    showToast('Saved');
  };

  // Haptics helper
  function buzz(ms=20){ try{ if(JSON.parse(localStorage.getItem('settings')||'{}').haptics && navigator.vibrate) navigator.vibrate(ms);}catch{} }

  // --------- Focus Tap ---------
  const fStage = $('#focusStage'), fStatus=$('#focusStatus'), fStart=$('#focusStart'), fStop=$('#focusStop');
  let fTimer=null, fOn=false, fScore=0, fTrials=0;
  fStart.onclick = ()=>{
    fOn=true; fScore=0; fTrials=0; fStatus.textContent='Tap the blue circle quickly.'; fStart.disabled=true; fStop.disabled=false;
    nextCue();
  };
  fStop.onclick = stopFocus;
  function stopFocus(){ fOn=false; clearTimeout(fTimer); fStart.disabled=false; fStop.disabled=true; fStatus.textContent=`Score: ${fScore}/${fTrials}`; }
  function nextCue(){
    if(!fOn) return;
    const delay = 400 + Math.random()*1200;
    fTimer = setTimeout(()=>{
      const size = 40;
      const w = fStage.clientWidth||300, h = fStage.clientHeight||200;
      const x = 20 + Math.random()*(w-60), y = 20 + Math.random()*(h-60);
      fStage.innerHTML = `<div id="cue" style="position:relative;width:100%;height:${h}px">
        <div style="position:absolute;left:${x}px;top:${y}px;width:${size}px;height:${size}px;background:#3a97ff;border-radius:50%"></div>
      </div>`;
      const t0 = performance.now();
      const handler = ()=>{ const rt = performance.now()-t0; fScore++; fTrials++; buzz(); fStatus.textContent=`Hit! RT ${rt|0} ms`; nextCue(); };
      $('#cue').onclick = handler;
      setTimeout(()=>{ if($('#cue')){ fTrials++; fStatus.textContent='Miss'; nextCue(); }}, 1200);
    }, delay);
  }

  // --------- Circle Hunt (moving target) ---------
  const cCan = $('#circleCanvas'), cCtx = cCan.getContext('2d'), cStart=$('#circleStart'), cStop=$('#circleStop'), cStatus=$('#circleStatus');
  let cOn=false, cx=60, cy=60, cvx=2, cvy=1.6, cr=16, rafId=null;
  cStart.onclick = ()=>{ cOn=true; cStart.disabled=true; cStop.disabled=false; loop(); };
  cStop.onclick = ()=>{ cOn=false; cStart.disabled=false; cStop.disabled=true; cancelAnimationFrame(rafId); };
  function loop(){
    if(!cOn) return;
    cCtx.clearRect(0,0,cCan.width,cCan.height);
    cx+=cvx; cy+=cvy;
    if(cx-cr<0||cx+cr>cCan.width) cvx*=-1;
    if(cy-cr<0||cy+cr>cCan.height) cvy*=-1;
    cCtx.fillStyle="#3a97ff"; cCtx.beginPath(); cCtx.arc(cx,cy,cr,0,Math.PI*2); cCtx.fill();
    rafId = requestAnimationFrame(loop);
  }
  cCan.addEventListener('click',(e)=>{
    const rect=cCan.getBoundingClientRect(), x=e.clientX-rect.left, y=e.clientY-rect.top;
    const d=Math.hypot(x-cx,y-cy);
    if(d<=cr){ buzz(); cStatus.textContent='Hit!'; }
    else cStatus.textContent='Miss';
  });

  // --------- Visual Span (grid sequence) ---------
  const vStage=$('#visualStage'), vStart=$('#visualStart'), vStop=$('#visualStop'), vStatus=$('#visualStatus');
  let vOn=false;
  vStart.onclick=()=>{ vOn=true; vStart.disabled=true; vStop.disabled=false; runSpan(); };
  vStop.onclick=()=>{ vOn=false; vStart.disabled=false; vStop.disabled=true; };
  function runSpan(){
    const cols=4, size=56, gap=10, total=16;
    vStage.innerHTML=`<div id="g" style="display:grid;grid-template-columns:repeat(${cols},${size}px);gap:${gap}px;justify-content:flex-start"></div><div class="muted">Repeat the flash sequence.</div>`;
    const g = $('#g');
    for(let i=0;i<total;i++){ const b=document.createElement('div'); b.className='box'; b.style.cssText=`width:${size}px;height:${size}px;background:#2a3340;border-radius:10px`; b.dataset.idx=i; g.appendChild(b); }
    const seq=[]; while(seq.length<4){ const v=Math.floor(Math.random()*total); if(!seq.includes(v)) seq.push(v); }
    let k=0;
    const id=setInterval(()=>{
      if(k>0) g.children[seq[k-1]].style.background="#2a3340";
      if(k<seq.length){ g.children[seq[k]].style.background="#3a97ff"; k++; }
      else { clearInterval(id); collect(); }
    },600);
    function collect(){
      let pos=0;
      [...g.children].forEach(b=>b.onclick=()=>{
        if(+b.dataset.idx===seq[pos]){ b.style.background="#2bd673"; pos++; if(pos===seq.length){ vStatus.textContent='Correct'; setTimeout(()=>{ if(vOn) runSpan(); },400);} }
        else { b.style.background="#ff5a5a"; setTimeout(()=>{ if(vOn) runSpan(); },400); }
      });
    }
  }

  // --------- 1-Back (letters) ---------
  const nbStage=$('#nbackStage'), nbStart=$('#nbackStart'), nbStatus=$('#nbackStatus');
  nbStart.onclick=()=>{
    const letters="ABCDEFGHJKLMNPQRSTUVWXYZ".split('');
    let prev=null, idx=0, hits=0, falses=0, totalTargets=0;
    const seq=[];
    for(let i=0;i<20;i++){ const makeMatch=Math.random()<0.25 && prev!==null; const ch=makeMatch?prev:letters[(Math.random()*letters.length)|0]; seq.push(ch); prev=ch; }
    for(let i=1;i<seq.length;i++) if(seq[i]===seq[i-1]) totalTargets++;
    nbStage.innerHTML=`<div style="font-size:42px;margin:10px 0" id="bigL">+</div><div class="row"><button class="btn primary" id="hit">Hit</button><button class="btn" id="miss">No</button></div>`;
    const big=$('#bigL'), hit=$('#hit'), miss=$('#miss'); let allow=false;
    hit.onclick=()=>{ if(!allow) return; const t=idx>0 && seq[idx]===seq[idx-1]; if(t) hits++; else falses++; allow=false; };
    miss.onclick=()=>{ if(!allow) return; const t=idx>0 && seq[idx]===seq[idx-1]; if(t) falses++; allow=false; };
    function step(){ if(idx>=seq.length){ finish(); return; } big.textContent=seq[idx]; allow=true; idx++; setTimeout(step,1800); }
    function finish(){ const acc= totalTargets? hits/totalTargets:0; nbStatus.textContent=`Accuracy ${ (acc*100)|0 }%`; }
    setTimeout(step,800);
  };

  // --------- Matrix Mini (toy) ---------
  const mStage=$('#matrixStage'), mStart=$('#matrixStart'), mStatus=$('#matrixStatus');
  mStart.onclick=()=>{
    // simple 2x3 -> choose missing (fake)
    const correct = (Math.random()*6)|0;
    const opts=[0,1,2,3]; opts.sort(()=>Math.random()-.5);
    mStage.innerHTML=`<p>Pick the missing tile (toy)</p>` + opts.map(o=>`<button class="btn choice" data-i="${o}">Tile ${o+1}</button>`).join(' ');
    mStage.querySelectorAll('.choice').forEach(b=>b.onclick=(e)=>{
      const pick=+e.target.dataset.i; if(pick===correct){ mStatus.textContent='Correct'; buzz(); } else mStatus.textContent='Wrong';
    });
  };

  // --------- Noticing 60s ---------
  $('#noticingStart').onclick=()=>{
    let t=60; $('#noticingStage').textContent='Notice: sounds, sights, body, thoughts...'; const id=setInterval(()=>{ t--; $('#noticingStatus').textContent=`${t}s left`; if(t<=0){ clearInterval(id); $('#noticingStatus').textContent='Done.';} },1000);
  };

  // --------- Journal ---------
  $('#journalSave').onclick=()=>{
    const v = $('#journalText').value.trim(); if(!v){ showToast('Nothing to save'); return; }
    const all = JSON.parse(localStorage.getItem('journals')||'[]'); all.push({ts:Date.now(), text:v}); localStorage.setItem('journals', JSON.stringify(all));
    $('#journalText').value=''; $('#journalStatus').textContent='Saved.'; showToast('Saved');
  };

  // --------- Stats ---------
  $('#statsRefresh').onclick=()=>{
    const iq = JSON.parse(localStorage.getItem('iq_full_runs')||'[]');
    const jn = JSON.parse(localStorage.getItem('journals')||'[]');
    const gz = JSON.parse(localStorage.getItem('gaze_sessions')||'[]');
    $('#statsStage').innerHTML = `
      <p><b>IQ runs:</b> ${iq.length}</p>
      <p><b>Journals:</b> ${jn.length}</p>
      <p><b>Eye sessions:</b> ${gz.length}</p>
    `;
  };
  $('#resetAll').onclick=()=>{ localStorage.clear(); showToast('All reset'); };

})();
